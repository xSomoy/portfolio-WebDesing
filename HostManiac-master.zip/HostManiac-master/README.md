# HostManiac

<table aligh="center">
  <tr>
    <td>Total Visits</td>
    <td><img src="https://profile-counter.glitch.me/xsomoy/count.svg" alt="xSomoy" /></td>
  </tr>
</table>
